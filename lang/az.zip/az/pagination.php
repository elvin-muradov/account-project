<?php

return [

  'previous' => '&laquo; Əvvəl',
  'next' => 'Sonra &raquo;',

];
