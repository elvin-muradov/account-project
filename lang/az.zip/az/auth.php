<?php

return [



  'failed' => 'İstifadəçi adı və ya şifrə səhvdir',
  'throttle' => ':seconds saniyə ərzində yenidən cəhd edin',

];
