<?php

return [
    "MICRO" => 'Mikro',
    "JUNIOR" => 'Kiçik',
    "MIDDLE" => 'Orta',
    "SENIOR" => 'İri',
];
