<?php

return [
    "MICRO" => 'Micro',
    "JUNIOR" => 'Junior',
    "MIDDLE" => 'Middle',
    "SENIOR" => 'Senior',
];
